# Full local draft PR: System Apps

Title: Add opt-in resident remote battery Quick Actions with explicit session selection
Base: main at 7270a10ed9cefba6ec1368060196a13bb3370985
Branch: tasker/t061-session-battery-local
Commit: 2fb0af77dec58eca931099a29c81468529745b96
Status: LOCAL DRAFT ONLY. No remote branch or PR created.

## Requested outcome

T061 asks for Watch battery over Bluetooth in X4 Quick Actions, retaining the
last acquired value and separately indicating present acquisition, before shared
app UI refactors. The current and published X4 sheets display only local board
battery. Existing telemetry releases alone do not deliver this integration.

## Changes

- Optional shared resident-host page, explicit bounded Scan/Stop and address/type
  selection. No first/nearest/name matching, background scan or automatic RF.
- Last value retained in RAM, sampled current indicator, stale/invalid/ambiguous
  rejection, per-peer cache isolation and random-session reselection notice.
- Fail-closed token/grant cleanup, post-close restoration warning, terminal
  Home/crown and alarm handling, captured queue epoch/index and dismissal guards.
- Actual renderer with seven software captures; local battery remains visible.
- Explicit build opt-in and caller-supplied numeric local candidate version,
  plus optional sensor declaration that does not create owner grants.
- Component, exhaustive controller, real adapter/atomic-queue, cross-repository
  codec/parser/consumer and actual Runtime optional-admission tests.

## Required paired dependency

Pair with Drivers commit ba28f9bdfbe84d23de36350189cc2ec89fea1677.
An older sensor parser silently chooses the final BTHome service-data field from
an ambiguous advertisement. The new consumer cannot recover discarded fields.
The paired fix invalidates repeated fields, preserving valid single-field data.
Do not deploy this consumer against the older retained sensors ELF.

## Verification and review

See REPORT.md, qualification.json, exact logs/receipts and screenshots. Normal
and ASan/UBSan tests pass; leak detection is disabled under ptrace. Independent
review findings repaired: queued Scan after dismissal, duplicate service-data
ambiguity, post-close restoration, terminal Home/crown, and optional admission.
Feature-disabled production host objects are byte-identical to the base.

## Not in this PR / remaining gates

No target ELF/firmware, physical RF, flash, hardware acceptance or remote CI.
No product source pin, accepted artifact/version, release, catalog, default
feature selection, pairing/security or owner grant changed. Public broadcast
identity is not authenticated ownership, and selection/cache are not persisted.
0.4.21 is only an unreserved test input. Target version allocation, paired
provider artifact generation, source-pinned product integration and Watch/X4
acceptance remain open. Publication is held.

# Full local draft PR: Drivers

Title: Reject ambiguous repeated BTHome service-data fields
Base: a7ae39994603c4545a3c014f09051ecfc12084d2
Branch: tasker/t061-battery-provider-local
Head: ba28f9bdfbe84d23de36350189cc2ec89fea1677
Distinct test-only checkpoint: fe310f01a90a616ce05be02b677debdf3cfcd607
Status: LOCAL DRAFT ONLY. No remote branch or PR created.

## Reproduction and fix

An advertisement containing 06 16 D2 FC 40 01 28 followed by
06 16 D2 FC 40 01 50 previously returned one valid 80% reading, silently
choosing the last field. It now reports measurement_invalid, no valid metric
readings and no battery/temperature/humidity flags, while preserving presence.
It recovers on a later unambiguous single service-data field. Multi-metric
readings within one valid field are not arbitrarily discarded.

## Tests

Six existing/new driver suites pass normally and under ASan/UBSan. Cross-contract
roundtrip covers all 101 percentages, observed address/type, measurement freshness,
malformed/encrypted data and repeated service-data valid/encrypted/invalid orderings.
The System actual codec/parser/consumer test validates last-value preservation
and noncurrent state through ambiguity, then recovery. No hardware test occurred.

## Limits

The code change does not publish a provider artifact, alter its released
manifest version or replace accepted bytes. Future delivery requires a separately
versioned, rebuilt and product-qualified provider paired with the System change.
