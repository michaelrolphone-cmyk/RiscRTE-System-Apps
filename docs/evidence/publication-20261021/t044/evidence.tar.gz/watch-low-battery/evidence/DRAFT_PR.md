Title: Fix low-battery timer fixture gesture scheduling

## Summary

- Repair the existing low-battery Settings timer regression's input schedule.
- Allow neutral page-entry polls before the increment and separate Save/Cancel gestures rather than treating consecutive contact samples as separate taps.
- Preserve every exact timer, persistence, Save/Cancel, failed-save and retry assertion.
- Make no production policy, SDK, manifest, version, source-pin or release changes.

## Reproduction

At base `7270a10ed9cefba6ec1368060196a13bb3370985`, `python3 scripts/test_low_battery.py` fails adapter case 2: the scripted increment is not admitted during page entry, so Save keeps the 20-second timer and the unchanged 25-second assertion fails. Core crossing/manual-override tests and the focused non-timer adapter cases pass. This is a fixture scheduling failure, not evidence that the production low-battery transition is missing.

## Change

The timer fixture schedules increment at poll 10, Save/Cancel at 20 and fallback Cancel at 40, replacing the premature 3/7/8/12 sequence. Adjacent 7/8 samples were one held contact in the ordered raw provider. Production sources and assertions are unchanged.

## Validation

- Full current low-battery suite: 44 executions passed, normal and ASan/UBSan, rotations 0/180.
- Native timer matrix: 220 executions passed across five geometries, both rotations, normal and ASan/UBSan.
- Independent focused rerun: four policy configurations and eight timer adapter executions passed.
- Watch canonical power union: 10 programs passed, normal/sanitized.
- Watch frozen-profile/version gates: five tests passed.
- Original accepted System low-battery suite: 38 executions passed; recovered Watch Clock/Hybrid suite with accepted System pin: four passed.
- `git diff --check` passed.

## Delivery and scope

The production feature already shipped through System Apps PR #56 and Watch 1.0.7. This PR does not introduce or republish it. Existing first-valid-low behavior, persistent manual overrides, rearm boundary, invalid sample handling and failure behavior remain untouched.

Physical behavior/current consumption and a new exact product cohort are not qualified by these host checks. Historical accepted Watch source could not be fetched by its source SHA; published build evidence/provenance were verified. The direct current/current legacy Watch runner's frozen-header mismatch remains an explicit qualification boundary, with a separate explicit canonical source-union proof.

Prepared locally on `tasker/t044-low-battery-qualification-20261021`, commit `df045bcdb30fa95650156ab9ad9f977f2ca8382a`. Publication is on hold. No branch push or PR creation is included in this task.
